﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VitalsApi.Data;
using VitalsApi.Models;
using VitalsApi.Services;

namespace VitalsApi.Controllers;

/// <summary>Medication orders: one list per patient (not tied to a chart day).</summary>
[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private const int MaxRows = 100;

    private readonly VitalsDbContext _db;
    private readonly IInpatientVerifier _verifier;

    public OrdersController(VitalsDbContext db, IInpatientVerifier verifier)
    {
        _db = db;
        _verifier = verifier;
    }

    private static List<OrderRowDto> ToDtos(IEnumerable<PatientOrder> rows) =>
        rows.OrderBy(r => r.SortOrder)
            .Select(r => new OrderRowDto
            {
                Drug = r.Drug,
                Dose = r.Dose,
                Route = r.Route,
                Frequency = r.Frequency,
                Interval = r.TimeInterval
            })
            .ToList();

    [HttpGet("patient/{patientIdentifier}")]
    [ProducesResponseType(typeof(List<OrderRowDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<OrderRowDto>>> Get(string patientIdentifier)
    {
        var rows = await _db.PatientOrders
            .Where(o => o.PatientIdentifier == patientIdentifier)
            .ToListAsync();
        return Ok(ToDtos(rows));
    }

    /// <summary>Replaces the whole order list for that patient.</summary>
    [HttpPut("patient/{patientIdentifier}")]
    [ProducesResponseType(typeof(List<OrderRowDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<List<OrderRowDto>>> Save(string patientIdentifier, List<OrderRowDto> rows)
    {
        if (rows.Count > MaxRows)
        {
            return BadRequest(new { message = $"Too many rows (maximum {MaxRows})." });
        }

        var problem = await _verifier.VerifyAsync(patientIdentifier);
        if (problem is not null)
        {
            return StatusCode(problem.StatusCode, new { message = problem.Message });
        }

        var existing = await _db.PatientOrders
            .Where(o => o.PatientIdentifier == patientIdentifier)
            .ToListAsync();
        _db.PatientOrders.RemoveRange(existing);

        var now = ChartClock.Now;
        var order = 0;
        foreach (var r in rows)
        {
            if (string.IsNullOrWhiteSpace(r.Drug) && string.IsNullOrWhiteSpace(r.Dose) &&
                string.IsNullOrWhiteSpace(r.Route) && string.IsNullOrWhiteSpace(r.Frequency) &&
                string.IsNullOrWhiteSpace(r.Interval))
            {
                continue; // skip fully blank rows
            }

            _db.PatientOrders.Add(new PatientOrder
            {
                PatientIdentifier = patientIdentifier,
                SortOrder = order++,
                Drug = r.Drug?.Trim(),
                Dose = r.Dose?.Trim(),
                Route = r.Route?.Trim(),
                Frequency = r.Frequency?.Trim(),
                TimeInterval = r.Interval?.Trim(),
                UpdatedAt = now
            });
        }

        await _db.SaveChangesAsync();

        var saved = await _db.PatientOrders
            .Where(o => o.PatientIdentifier == patientIdentifier)
            .ToListAsync();
        return Ok(ToDtos(saved));
    }
}
