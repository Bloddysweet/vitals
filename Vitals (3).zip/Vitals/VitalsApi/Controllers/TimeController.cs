﻿using Microsoft.AspNetCore.Mvc;
using VitalsApi.Services;

namespace VitalsApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TimeController : ControllerBase
{
    /// <summary>
    /// The server's India time. The pages use this instead of the phone's own clock, so a wrong
    /// phone clock or time zone can't show the wrong chart day or the wrong entry time.
    /// </summary>
    [HttpGet("now")]
    public IActionResult Now()
    {
        var now = ChartClock.Now;
        return Ok(new
        {
            now = now.ToString("yyyy-MM-ddTHH:mm:ss"),
            chartDate = ChartClock.CurrentChartDate.ToString("yyyy-MM-dd")
        });
    }
}
