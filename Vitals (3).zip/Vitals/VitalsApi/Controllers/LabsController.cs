﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VitalsApi.Data;
using VitalsApi.Models;
using VitalsApi.Services;

namespace VitalsApi.Controllers;

/// <summary>Investigations (labs): one list per patient per chart day.</summary>
[ApiController]
[Route("api/[controller]")]
public class LabsController : ControllerBase
{
    private const int MaxRows = 100;

    private readonly VitalsDbContext _db;
    private readonly IInpatientVerifier _verifier;

    public LabsController(VitalsDbContext db, IInpatientVerifier verifier)
    {
        _db = db;
        _verifier = verifier;
    }

    private static List<LabRowDto> ToDtos(IEnumerable<PatientLab> rows) =>
        rows.OrderBy(r => r.SortOrder)
            .Select(r => new LabRowDto { Test = r.Test, Result = r.Result, Range = r.ReferenceRange })
            .ToList();

    [HttpGet("patient/{patientIdentifier}/date/{date}")]
    [ProducesResponseType(typeof(List<LabRowDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<LabRowDto>>> Get(string patientIdentifier, DateTime date)
    {
        var rows = await _db.PatientLabs
            .Where(l => l.PatientIdentifier == patientIdentifier && l.LabDate == date.Date)
            .ToListAsync();
        return Ok(ToDtos(rows));
    }

    /// <summary>Replaces the whole list for that patient and day. Only the current chart day can be changed.</summary>
    [HttpPut("patient/{patientIdentifier}/date/{date}")]
    [ProducesResponseType(typeof(List<LabRowDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<List<LabRowDto>>> Save(string patientIdentifier, DateTime date, List<LabRowDto> rows)
    {
        if (rows.Count > MaxRows)
        {
            return BadRequest(new { message = $"Too many rows (maximum {MaxRows})." });
        }

        var day = date.Date;
        var today = ChartClock.CurrentChartDate;
        if (day < today)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                message = "This chart day is complete. Investigations from a past day can no longer be changed."
            });
        }
        if (day > today)
        {
            return BadRequest(new { message = "Investigations can't be saved for a future day." });
        }

        var problem = await _verifier.VerifyAsync(patientIdentifier);
        if (problem is not null)
        {
            return StatusCode(problem.StatusCode, new { message = problem.Message });
        }

        var existing = await _db.PatientLabs
            .Where(l => l.PatientIdentifier == patientIdentifier && l.LabDate == day)
            .ToListAsync();
        _db.PatientLabs.RemoveRange(existing);

        var now = ChartClock.Now;
        var order = 0;
        foreach (var r in rows)
        {
            if (string.IsNullOrWhiteSpace(r.Test) && string.IsNullOrWhiteSpace(r.Result) && string.IsNullOrWhiteSpace(r.Range))
            {
                continue; // skip fully blank rows
            }

            _db.PatientLabs.Add(new PatientLab
            {
                PatientIdentifier = patientIdentifier,
                LabDate = day,
                SortOrder = order++,
                Test = r.Test?.Trim(),
                Result = r.Result?.Trim(),
                ReferenceRange = r.Range?.Trim(),
                UpdatedAt = now
            });
        }

        await _db.SaveChangesAsync();

        var saved = await _db.PatientLabs
            .Where(l => l.PatientIdentifier == patientIdentifier && l.LabDate == day)
            .ToListAsync();
        return Ok(ToDtos(saved));
    }
}
