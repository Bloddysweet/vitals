﻿using Microsoft.AspNetCore.Mvc;
using VitalsApi.Models;
using VitalsApi.Services;

namespace VitalsApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PatientsController : ControllerBase
{
    private readonly IHospitalPatientService _hospitalPatientService;
    private readonly ILogger<PatientsController> _logger;
    private readonly string[] _admittedStatusCodes;

    public PatientsController(
        IHospitalPatientService hospitalPatientService,
        ILogger<PatientsController> logger,
        IConfiguration configuration)
    {
        _hospitalPatientService = hospitalPatientService;
        _logger = logger;

        _admittedStatusCodes = InpatientRules.LoadAdmittedCodes(configuration);
    }

    [HttpGet("lookup/{id}")]
    [ProducesResponseType(typeof(PatientInfo), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status502BadGateway)]
    public async Task<ActionResult<PatientInfo>> Lookup(string id, CancellationToken cancellationToken)
    {
        PatientInfo? patient;
        try
        {
            patient = await _hospitalPatientService.LookupAsync(id, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Hospital patient API unreachable");
            return StatusCode(StatusCodes.Status502BadGateway, "Could not reach the hospital patient system.");
        }

        if (patient is null)
        {
            return NotFound();
        }

        // ICU charting is for current inpatients only.
        var reason = InpatientRules.Check(patient, _admittedStatusCodes);
        if (reason is not null)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { message = reason });
        }

        return Ok(patient);
    }
}