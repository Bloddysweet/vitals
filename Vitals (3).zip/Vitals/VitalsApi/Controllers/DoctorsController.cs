﻿using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;

namespace VitalsApi.Controllers;

/// <summary>
/// Doctor-wise current inpatients, using the hospital's current admission records.
/// Copy this file into the existing VitalsApi/Controllers folder.
/// Uses the existing Oracle:ConnectionString configuration and Oracle provider.
/// No table creation, EF entity changes, or Program.cs changes are required.
///
/// SECURITY: intentionally Development-only until doctor login and server-side
/// assignment authorization are implemented. Do not remove this restriction or
/// enable Development on a public server merely to expose this endpoint.
/// Later, derive the doctor identity from authenticated claims and authorize the
/// requested doctor code and patient access on EVERY relevant backend endpoint.
/// A doctor code, read-only HTML, or a ?readOnly=true URL is not authorization.
/// </summary>
[ApiController]
[Route("api/Doctors")]
[Produces("application/json")]
[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public sealed class DoctorsController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private readonly IHostEnvironment _environment;
    private readonly ILogger<DoctorsController> _logger;

    // DOCTCODE is VARCHAR2(10). Codes can be alphanumeric, not just numeric.
    private static readonly Regex DoctorCodePattern = new(
        @"\A[A-Za-z0-9_-]{1,10}\z", RegexOptions.CultureInvariant,
        TimeSpan.FromMilliseconds(100));

    private const string PatientsSql = """
        SELECT
            a.IPATIENTID,
            a.PRNO,
            p.FIRSTNAME AS PATIENT_NAME,
            p.AGENEW AS AGE,
            p.SEX,
            a.DOCTCODE,
            a.CASETYPE AS WARD,
            a.BEDID,
            a.DEPTCODE,
            d.DEPTNAME AS DEPARTMENT,
            a.ADMITDATE,
            a.DISGSTATUS
        FROM WHISPROD.IPADMISSION_DETAILS a
        LEFT JOIN WHISPROD.MASTERPATIENTREGISTRATION p
            ON p.PRNO = a.PRNO
        LEFT JOIN WHISPROD.MASTERDEPARTMENTS d
            ON d.DEPTCODE = a.DEPTCODE
        WHERE a.DISGSTATUS = 'A'
          AND a.DOCTCODE = :doctorCode
        ORDER BY a.ADMITDATE DESC, a.IPATIENTID DESC
        """;

    public DoctorsController(
        IConfiguration configuration,
        IHostEnvironment environment,
        ILogger<DoctorsController> logger)
    {
        _configuration = configuration;
        _environment = environment;
        _logger = logger;
    }

    /// <summary>
    /// GET /api/Doctors/40801279/patients
    /// Returns 200 with an empty list for an unknown code or no active admissions;
    /// this endpoint does not establish whether a doctor account exists.
    /// Dates are ISO 8601 hospital wall-clock values; identifiers remain strings.
    /// </summary>
    [HttpGet("{doctorCode}/patients")]
    [ProducesResponseType(typeof(DoctorPatientsResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<DoctorPatientsResponse>> GetPatients(
        [FromRoute] string doctorCode, CancellationToken cancellationToken)
    {
        if (!_environment.IsDevelopment())
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                message = "Doctor patient access is not enabled until doctor authentication and authorization are configured."
            });
        }

        var code = doctorCode.Trim();
        if (!DoctorCodePattern.IsMatch(code))
        {
            return BadRequest(new
            {
                message = "Doctor code must contain 1 to 10 letters, digits, underscores or hyphens."
            });
        }

        var connectionString = _configuration["Oracle:ConnectionString"];
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            _logger.LogError("Oracle:ConnectionString is not configured.");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                message = "The hospital database connection is not configured."
            });
        }

        try
        {
            using var connection = new OracleConnection(connectionString);
            await connection.OpenAsync(cancellationToken);

            using var command = connection.CreateCommand();
            command.BindByName = true;
            command.CommandType = CommandType.Text;
            command.CommandText = PatientsSql;
            command.CommandTimeout = 30;
            command.Parameters.Add(new OracleParameter("doctorCode", OracleDbType.Varchar2)
            {
                Size = 10,
                Direction = ParameterDirection.Input,
                Value = code
            });

            using var reader = await command.ExecuteReaderAsync(
                CommandBehavior.SingleResult, cancellationToken);
            var patients = new List<DoctorPatientDto>();
            while (await reader.ReadAsync(cancellationToken))
            {
                var ageText = ReadText(reader, 3);
                int? age = int.TryParse(ageText, NumberStyles.Integer,
                    CultureInfo.InvariantCulture, out var parsedAge) ? parsedAge : null;

                patients.Add(new DoctorPatientDto
                {
                    // The existing ICU dashboard uses this inpatient ID in ?patientId=.
                    PatientId = ReadText(reader, 0) ?? string.Empty,
                    Prno = ReadText(reader, 1) ?? string.Empty,
                    FullName = ReadText(reader, 2),
                    Age = age,
                    Sex = ReadText(reader, 4),
                    DoctorCode = ReadText(reader, 5) ?? code,
                    Ward = ReadText(reader, 6),
                    BedId = ReadText(reader, 7),
                    DepartmentCode = ReadText(reader, 8),
                    Department = ReadText(reader, 9),
                    AdmittedOn = reader.IsDBNull(10) ? null
                        : DateTime.SpecifyKind(reader.GetDateTime(10), DateTimeKind.Unspecified),
                    DischargeStatus = ReadText(reader, 11)
                });
            }

            return Ok(new DoctorPatientsResponse
            {
                DoctorCode = code,
                TotalPatients = patients.Count,
                Patients = patients
            });
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (OracleException ex)
        {
            // Do not return connection strings, raw SQL, patient details or Oracle
            // exception text to the browser. Diagnostics stay in protected server logs.
            _logger.LogError(ex, "Could not load doctor-wise admitted patients.");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                message = "Could not load admitted patients from the hospital database. Please try again later."
            });
        }
    }

    private static string? ReadText(DbDataReader reader, int ordinal) =>
        reader.IsDBNull(ordinal) ? null
            : Convert.ToString(reader.GetValue(ordinal), CultureInfo.InvariantCulture)?.Trim();
}

// DTOs are included here so this addition requires only ONE new file.
public sealed class DoctorPatientsResponse
{
    public string DoctorCode { get; init; } = string.Empty;
    public int TotalPatients { get; init; }
    public IReadOnlyList<DoctorPatientDto> Patients { get; init; } = Array.Empty<DoctorPatientDto>();
}

public sealed class DoctorPatientDto
{
    public string PatientId { get; init; } = string.Empty;
    public string Prno { get; init; } = string.Empty;
    public string? FullName { get; init; }
    public int? Age { get; init; }
    public string? Sex { get; init; }
    public string DoctorCode { get; init; } = string.Empty;
    public string? Ward { get; init; }
    public string? BedId { get; init; }
    public string? DepartmentCode { get; init; }
    public string? Department { get; init; }
    public DateTime? AdmittedOn { get; init; }
    public string? DischargeStatus { get; init; }
}