﻿/*
 * Shared barcode scanner (used by patient-select.html and icu-dashboard.html).
 *
 * Usage:   BarcodeScan.open(code => { ...use the scanned text... });
 *
 * - Live camera scanning (rear camera). Browsers only allow camera access on https or
 *   localhost, so on a plain-http address it falls back to "Take photo of barcode".
 * - Decoding is done by html5-qrcode (loaded from a CDN on first use, so no page weight
 *   until someone actually scans). To work offline, download html5-qrcode.min.js into
 *   wwwroot and point LIB_URL at "html5-qrcode.min.js".
 */
(function () {
    'use strict';

    var LIB_URL = 'https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js';

    var libPromise = null;
    var overlay = null;
    var scanner = null;      // live-camera instance
    var onResult = null;
    var finished = false;

    var CSS = '' +
        '.bcs-backdrop{position:fixed;inset:0;z-index:99999;background:rgba(10,18,30,.82);display:none;align-items:center;justify-content:center;padding:12px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}' +
        '.bcs-backdrop.open{display:flex}' +
        '.bcs-panel{background:#fff;color:#1b2430;border-radius:16px;width:100%;max-width:440px;padding:16px;box-shadow:0 20px 50px rgba(0,0,0,.35)}' +
        '.bcs-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}' +
        '.bcs-head h3{margin:0;font-size:17px}' +
        '.bcs-reader{width:100%;min-height:120px;background:#0b1320;border-radius:12px;overflow:hidden}' +
        '.bcs-status{font-size:13px;color:#4a5668;margin:10px 2px 0;min-height:18px}' +
        '.bcs-status.err{color:#b3261e}' +
        '.bcs-actions{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}' +
        '.bcs-btn{flex:1;min-width:120px;padding:11px 14px;font-size:14px;font-weight:600;border-radius:10px;border:1px solid #c9d2de;background:#f4f7fb;color:#1b2430;cursor:pointer}' +
        '.bcs-btn.primary{background:#0f4c81;border-color:#0f4c81;color:#fff}' +
        '.bcs-btn:disabled{opacity:.6}' +
        '.bcs-file{display:none}';

    function injectStyles() {
        if (document.getElementById('bcs-style')) return;
        var st = document.createElement('style');
        st.id = 'bcs-style';
        st.textContent = CSS;
        document.head.appendChild(st);
    }

    function buildOverlay() {
        if (overlay) return;
        injectStyles();
        overlay = document.createElement('div');
        overlay.className = 'bcs-backdrop';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-label', 'Scan patient barcode');
        overlay.innerHTML =
            '<div class="bcs-panel">' +
            '<div class="bcs-head"><h3>Scan patient barcode</h3></div>' +
            '<div class="bcs-reader" id="bcs-reader"></div>' +
            '<div class="bcs-status" id="bcs-status" aria-live="polite"></div>' +
            '<div class="bcs-actions">' +
            '<button type="button" class="bcs-btn" id="bcs-photo">Take photo instead</button>' +
            '<button type="button" class="bcs-btn primary" id="bcs-cancel">Cancel</button>' +
            '</div>' +
            '<input type="file" accept="image/*" capture="environment" class="bcs-file" id="bcs-file">' +
            '</div>';
        document.body.appendChild(overlay);

        document.getElementById('bcs-cancel').addEventListener('click', function () { close(); });
        document.getElementById('bcs-photo').addEventListener('click', function () {
            document.getElementById('bcs-file').click();
        });
        document.getElementById('bcs-file').addEventListener('change', onPhotoChosen);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && overlay.classList.contains('open')) close();
        });
    }

    function setStatus(text, isError) {
        var el = document.getElementById('bcs-status');
        if (!el) return;
        el.textContent = text || '';
        el.className = 'bcs-status' + (isError ? ' err' : '');
    }

    function loadLib() {
        if (window.Html5Qrcode) return Promise.resolve();
        if (!libPromise) {
            libPromise = new Promise(function (resolve, reject) {
                var s = document.createElement('script');
                s.src = LIB_URL;
                s.onload = resolve;
                s.onerror = function () { libPromise = null; reject(new Error('lib-load')); };
                document.head.appendChild(s);
            });
        }
        return libPromise;
    }

    function scannerConfig() {
        var F = window.Html5QrcodeSupportedFormats;
        return {
            formatsToSupport: [F.CODE_128, F.CODE_39, F.CODE_93, F.ITF, F.CODABAR,
                               F.EAN_13, F.EAN_8, F.UPC_A, F.UPC_E, F.QR_CODE],
            experimentalFeatures: { useBarCodeDetectorIfSupported: true },
            verbose: false
        };
    }

    async function stopCamera() {
        if (!scanner) return;
        var s = scanner;
        scanner = null;
        try { await s.stop(); } catch (e) { /* not running */ }
        try { s.clear(); } catch (e) { /* ignore */ }
    }

    async function close() {
        finished = true;
        await stopCamera();
        if (overlay) overlay.classList.remove('open');
    }

    function deliver(text) {
        if (finished) return;
        var code = String(text || '').trim();
        if (!code) return;
        finished = true;
        if (navigator.vibrate) { try { navigator.vibrate(120); } catch (e) { /* ignore */ } }
        var cb = onResult;
        close().then(function () { if (cb) cb(code); });
    }

    async function onPhotoChosen(ev) {
        var input = ev.target;
        var file = input.files && input.files[0];
        input.value = '';
        if (!file) return;
        setStatus('Reading barcode from photo...');
        try {
            await loadLib();
            await stopCamera();
            var inst = new window.Html5Qrcode('bcs-reader', scannerConfig());
            var text = await inst.scanFile(file, false);
            try { inst.clear(); } catch (e) { /* ignore */ }
            deliver(text);
        } catch (e) {
            setStatus("Couldn't read a barcode in that photo. Move closer, keep the barcode flat and in focus, and try again.", true);
        }
    }

    async function open(callback) {
        onResult = callback;
        finished = false;
        buildOverlay();
        overlay.classList.add('open');
        setStatus('Starting camera...');

        try {
            await loadLib();
        } catch (e) {
            setStatus('Could not load the scanner. Check the internet connection and try again.', true);
            return;
        }

        var camOk = window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
        if (!camOk) {
            setStatus('Live camera needs a secure (https) connection on this device. Tap "Take photo instead" to scan a photo of the barcode.', true);
            return;
        }

        try {
            await stopCamera();
            scanner = new window.Html5Qrcode('bcs-reader', scannerConfig());
            await scanner.start(
                { facingMode: 'environment' },
                {
                    fps: 10,
                    // wide, short box suits 1D barcodes
                    qrbox: function (w, h) {
                        return { width: Math.floor(w * 0.9), height: Math.floor(Math.min(h * 0.5, 170)) };
                    }
                },
                function (decodedText) { deliver(decodedText); },
                function () { /* no barcode in this frame: keep scanning */ }
            );
            setStatus('Point the camera at the barcode and hold steady.');
        } catch (e) {
            var denied = e && (e.name === 'NotAllowedError' || /permission/i.test(String(e)));
            setStatus(denied
                ? 'Camera permission was denied. Allow camera access for this site in the browser settings, or tap "Take photo instead".'
                : 'Could not start the camera. Tap "Take photo instead" to scan a photo of the barcode.', true);
        }
    }

    window.BarcodeScan = { open: open, close: close };
})();
