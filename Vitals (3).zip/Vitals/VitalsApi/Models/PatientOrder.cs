﻿using System.ComponentModel.DataAnnotations;

namespace VitalsApi.Models;

/// <summary>One medication order row for a patient (not tied to a chart day).</summary>
public class PatientOrder
{
    [Key]
    public int OrderId { get; set; }

    [Required, MaxLength(50)]
    public string PatientIdentifier { get; set; } = string.Empty; // hospital's ipatientid

    public int SortOrder { get; set; }

    [MaxLength(100)] public string? Drug { get; set; }
    [MaxLength(100)] public string? Dose { get; set; }
    [MaxLength(100)] public string? Route { get; set; }
    [MaxLength(100)] public string? Frequency { get; set; }
    [MaxLength(100)] public string? TimeInterval { get; set; }

    public DateTime UpdatedAt { get; set; }
}
