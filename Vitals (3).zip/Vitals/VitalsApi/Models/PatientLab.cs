﻿using System.ComponentModel.DataAnnotations;

namespace VitalsApi.Models;

/// <summary>One investigation result row for a patient on a chart day.</summary>
public class PatientLab
{
    [Key]
    public int LabId { get; set; }

    [Required, MaxLength(50)]
    public string PatientIdentifier { get; set; } = string.Empty; // hospital's ipatientid

    public DateTime LabDate { get; set; }   // chart day (date only)
    public int SortOrder { get; set; }

    [MaxLength(100)] public string? Test { get; set; }
    [MaxLength(100)] public string? Result { get; set; }
    [MaxLength(100)] public string? ReferenceRange { get; set; }

    public DateTime UpdatedAt { get; set; }
}
