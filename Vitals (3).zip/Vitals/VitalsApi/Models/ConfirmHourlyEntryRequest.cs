﻿using System.ComponentModel.DataAnnotations;

namespace VitalsApi.Models;

public class ConfirmHourlyEntryRequest
{
    [Required(ErrorMessage = "Patient is required.")]
    [StringLength(50)]
    public string PatientIdentifier { get; set; } = string.Empty;

    /// <summary>
    /// Set when editing an existing entry. When null, the server creates a new entry
    /// stamped with the current server time (EntryDate / Hour below are ignored).
    /// </summary>
    public int? EntryId { get; set; }

    // Ignored by the server (kept so older clients don't break): the entry's date and
    // time are decided server-side from the clock, or taken from the existing entry.
    public DateTime? EntryDate { get; set; }
    public string? Hour { get; set; }

    [Range(typeof(decimal), "85", "110", ErrorMessage = "Temperature must be between 85 and 110 °F.")]
    public decimal? Temperature { get; set; }
    [Range(6, 60, ErrorMessage = "Respiratory rate must be between 6 and 60.")]
    public int? RespiratoryRate { get; set; }
    [Range(30, 200, ErrorMessage = "Heart rate must be between 30 and 200.")]
    public int? HeartRate { get; set; }
    [Range(30, 200, ErrorMessage = "Pulse rate must be between 30 and 200.")]
    public int? PulseRate { get; set; }

    [StringLength(50, ErrorMessage = "Iabp is too long (max 50 characters).")]
    public string? Iabp { get; set; }
    [Range(50, 100, ErrorMessage = "SpO2 must be between 50 and 100.")]
    public int? SpO2 { get; set; }
    [Range(40, 300, ErrorMessage = "Systolic BP must be between 40 and 300.")]
    public int? NibpSystolic { get; set; }
    [Range(20, 200, ErrorMessage = "Diastolic BP must be between 20 and 200.")]
    public int? NibpDiastolic { get; set; }
    [Range(30, 250, ErrorMessage = "MAP must be between 30 and 250.")]
    public int? Map { get; set; }
    [StringLength(50, ErrorMessage = "Cvp is too long (max 50 characters).")]
    public string? Cvp { get; set; }

    [Range(40, 500, ErrorMessage = "Blood glucose must be between 40 and 500.")]
    public int? BloodGlucose { get; set; }
    [StringLength(100, ErrorMessage = "Insulin is too long (max 100 characters).")]
    public string? Insulin { get; set; }

    [StringLength(50, ErrorMessage = "AdrenalineStarted is too long (max 50 characters).")]
    public string? AdrenalineStarted { get; set; }
    [StringLength(50, ErrorMessage = "AdrenalineInfused is too long (max 50 characters).")]
    public string? AdrenalineInfused { get; set; }
    [StringLength(50, ErrorMessage = "NoradrenalineStarted is too long (max 50 characters).")]
    public string? NoradrenalineStarted { get; set; }
    [StringLength(50, ErrorMessage = "NoradrenalineInfused is too long (max 50 characters).")]
    public string? NoradrenalineInfused { get; set; }
    [StringLength(50, ErrorMessage = "DopamineStarted is too long (max 50 characters).")]
    public string? DopamineStarted { get; set; }
    [StringLength(50, ErrorMessage = "DopamineInfused is too long (max 50 characters).")]
    public string? DopamineInfused { get; set; }
    [StringLength(50, ErrorMessage = "DobutamineStarted is too long (max 50 characters).")]
    public string? DobutamineStarted { get; set; }
    [StringLength(50, ErrorMessage = "DobutamineInfused is too long (max 50 characters).")]
    public string? DobutamineInfused { get; set; }

    [Range(0, 2000, ErrorMessage = "Parenteral nutrition must be between 0 and 2000.")]
    public int? ParenteralNutrition { get; set; }
    [Range(0, 2000, ErrorMessage = "RT feeds must be between 0 and 2000.")]
    public int? RtFeeds { get; set; }
    [Range(0, 2000, ErrorMessage = "IV line 1 must be between 0 and 2000.")]
    public int? Iv1 { get; set; }
    [Range(0, 2000, ErrorMessage = "IV line 2 must be between 0 and 2000.")]
    public int? Iv2 { get; set; }

    [Range(0, 2000, ErrorMessage = "Drains must be between 0 and 2000.")]
    public int? Drains { get; set; }
    [StringLength(50, ErrorMessage = "Stool is too long (max 50 characters).")]
    public string? Stool { get; set; }
    [Range(0, 2000, ErrorMessage = "Urine must be between 0 and 2000.")]
    public int? Urine { get; set; }

    [StringLength(50, ErrorMessage = "VentMode is too long (max 50 characters).")]
    public string? VentMode { get; set; }
    [StringLength(50, ErrorMessage = "Fio2 is too long (max 50 characters).")]
    public string? Fio2 { get; set; }
    [StringLength(50, ErrorMessage = "RateSet is too long (max 50 characters).")]
    public string? RateSet { get; set; }
    [StringLength(50, ErrorMessage = "RateSpont is too long (max 50 characters).")]
    public string? RateSpont { get; set; }
    [StringLength(50, ErrorMessage = "TidalSet is too long (max 50 characters).")]
    public string? TidalSet { get; set; }
    [StringLength(50, ErrorMessage = "TidalSpont is too long (max 50 characters).")]
    public string? TidalSpont { get; set; }
    [StringLength(50, ErrorMessage = "MinVolSet is too long (max 50 characters).")]
    public string? MinVolSet { get; set; }
    [StringLength(50, ErrorMessage = "MinVolSpont is too long (max 50 characters).")]
    public string? MinVolSpont { get; set; }
    [StringLength(50, ErrorMessage = "Pc is too long (max 50 characters).")]
    public string? Pc { get; set; }
    [StringLength(50, ErrorMessage = "Peep is too long (max 50 characters).")]
    public string? Peep { get; set; }
    [StringLength(50, ErrorMessage = "Ps is too long (max 50 characters).")]
    public string? Ps { get; set; }
    [StringLength(50, ErrorMessage = "Pip is too long (max 50 characters).")]
    public string? Pip { get; set; }
    [StringLength(50, ErrorMessage = "VentSpo2 is too long (max 50 characters).")]
    public string? VentSpo2 { get; set; }
    [StringLength(50, ErrorMessage = "Etco2 is too long (max 50 characters).")]
    public string? Etco2 { get; set; }
    [StringLength(500, ErrorMessage = "ABG is too long (max 500 characters).")]
    public string? Abg { get; set; }

    [Range(1, 6, ErrorMessage = "GCS eye score is out of range.")]
    public int? GcsEye { get; set; }
    [Range(1, 6, ErrorMessage = "GCS motor score is out of range.")]
    public int? GcsMotor { get; set; }
    [Range(1, 6, ErrorMessage = "GCS verbal score is out of range.")]
    public int? GcsVerbal { get; set; }
    public bool MotorUpperR { get; set; }
    public bool MotorUpperL { get; set; }
    public bool MotorLowerR { get; set; }
    public bool MotorLowerL { get; set; }
    [StringLength(20, ErrorMessage = "Right pupil text is too long (max 20 characters).")]
    public string? PupilR { get; set; }
    [StringLength(20, ErrorMessage = "Left pupil text is too long (max 20 characters).")]
    public string? PupilL { get; set; }

    [StringLength(20, ErrorMessage = "ExtractionConfidence is too long (max 20 characters).")]
    public string? ExtractionConfidence { get; set; }
}