﻿using System.ComponentModel.DataAnnotations;

namespace VitalsApi.Models;

// What the pages send and receive for the Investigations / Medication orders tabs.

public class LabRowDto
{
    [StringLength(100, ErrorMessage = "Test is too long (max 100 characters).")]
    public string? Test { get; set; }

    [StringLength(100, ErrorMessage = "Result is too long (max 100 characters).")]
    public string? Result { get; set; }

    [StringLength(100, ErrorMessage = "Reference range is too long (max 100 characters).")]
    public string? Range { get; set; }
}

public class OrderRowDto
{
    [StringLength(100, ErrorMessage = "Drug is too long (max 100 characters).")]
    public string? Drug { get; set; }

    [StringLength(100, ErrorMessage = "Dose is too long (max 100 characters).")]
    public string? Dose { get; set; }

    [StringLength(100, ErrorMessage = "Route is too long (max 100 characters).")]
    public string? Route { get; set; }

    [StringLength(100, ErrorMessage = "Frequency is too long (max 100 characters).")]
    public string? Frequency { get; set; }

    [StringLength(100, ErrorMessage = "Time interval is too long (max 100 characters).")]
    public string? Interval { get; set; }
}
