﻿using VitalsApi.Models;

namespace VitalsApi.Services;

/// <summary>Why a patient may not be charted: the HTTP status to return and a readable message.</summary>
public sealed record InpatientProblem(int StatusCode, string Message);

public interface IInpatientVerifier
{
    /// <summary>Returns null when charting for this patient may go ahead, otherwise the problem.</summary>
    Task<InpatientProblem?> VerifyAsync(string patientIdentifier, CancellationToken cancellationToken = default);
}

/// <summary>
/// Server-side check that a patient is a current inpatient and that the identifier is the
/// inpatient ID (the pages always use it). Shared by saving vitals, labs and medication orders.
/// If the hospital system can't be reached we let the save through (and log it) so a nurse is
/// never blocked from charting by an outage; the page already checked the patient on load.
/// </summary>
public class InpatientVerifier : IInpatientVerifier
{
    private readonly IHospitalPatientService _hospital;
    private readonly ILogger<InpatientVerifier> _logger;
    private readonly string[] _admittedStatusCodes;

    public InpatientVerifier(
        IHospitalPatientService hospital,
        ILogger<InpatientVerifier> logger,
        IConfiguration configuration)
    {
        _hospital = hospital;
        _logger = logger;
        _admittedStatusCodes = InpatientRules.LoadAdmittedCodes(configuration);
    }

    public async Task<InpatientProblem?> VerifyAsync(string patientIdentifier, CancellationToken cancellationToken = default)
    {
        PatientInfo? patient;
        try
        {
            patient = await _hospital.LookupAsync(patientIdentifier, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex,
                "Could not verify patient {PatientIdentifier}: hospital system unreachable. Allowing the save.",
                patientIdentifier);
            return null;
        }

        if (patient is null)
        {
            return new InpatientProblem(StatusCodes.Status404NotFound, "Patient not found in the hospital system.");
        }

        var reason = InpatientRules.Check(patient, _admittedStatusCodes);
        if (reason is not null)
        {
            return new InpatientProblem(StatusCodes.Status403Forbidden, reason);
        }

        if (!string.Equals(patient.IpatientId?.Trim(), patientIdentifier.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            return new InpatientProblem(StatusCodes.Status400BadRequest,
                "PatientIdentifier must be the patient's inpatient ID.");
        }

        return null;
    }
}
