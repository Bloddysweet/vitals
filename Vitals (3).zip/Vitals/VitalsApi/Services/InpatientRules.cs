﻿using VitalsApi.Models;

namespace VitalsApi.Services;

/// <summary>
/// "Only current inpatients" rules, shared by patient lookup and by saving vitals.
/// </summary>
public static class InpatientRules
{
    /// <summary>Discharge-status codes that mean "still admitted" ("A" unless overridden in appsettings).</summary>
    public static string[] LoadAdmittedCodes(IConfiguration configuration)
    {
        var codes = configuration.GetSection("Hospital:AdmittedStatusCodes").Get<string[]>();
        return codes is { Length: > 0 } ? codes : new[] { "A" };
    }

    /// <summary>Returns null when the patient may be charted, otherwise the reason they may not.</summary>
    public static string? Check(PatientInfo patient, string[] admittedCodes)
    {
        // No inpatient ID -> OP-only patient, never admitted
        if (string.IsNullOrWhiteSpace(patient.IpatientId))
        {
            return "This patient has no inpatient admission, so they can't be opened for ICU charting.";
        }

        // Discharge status present and not an "admitted" code -> already discharged.
        // (A blank status is allowed through: we can't prove they were discharged.)
        var status = patient.DischargeStatus?.Trim();
        if (!string.IsNullOrEmpty(status) &&
            !admittedCodes.Contains(status, StringComparer.OrdinalIgnoreCase))
        {
            return "This patient is not currently admitted (already discharged), so they can't be opened for ICU charting.";
        }

        return null;
    }
}
