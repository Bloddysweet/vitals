﻿namespace VitalsApi.Services;

/// <summary>
/// The one place that decides "what time is it" for charting. Always India Standard Time
/// (UTC+05:30, no daylight saving), no matter which time zone the server machine is set to.
/// </summary>
public static class ChartClock
{
    private static readonly TimeSpan IstOffset = TimeSpan.FromMinutes(330);

    /// <summary>The nursing chart day starts at 07:00 and ends at 06:59 the next morning.</summary>
    public const int ShiftStartHour = 7;

    /// <summary>Current India time (Kind = Unspecified, like the values stored in Oracle).</summary>
    public static DateTime Now =>
        DateTime.SpecifyKind(DateTime.UtcNow + IstOffset, DateTimeKind.Unspecified);

    /// <summary>The chart day we are on right now (before 07:00 it is still the previous day).</summary>
    public static DateTime CurrentChartDate
    {
        get
        {
            var now = Now;
            return (now.Hour < ShiftStartHour ? now.AddDays(-1) : now).Date;
        }
    }
}
