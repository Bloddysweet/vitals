﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VitalsApi.Data;
using VitalsApi.Models;
using VitalsApi.Services;

namespace VitalsApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HourlyVitalsController : ControllerBase
{
    private static readonly TimeSpan EntryLockAfter = TimeSpan.FromHours(24);

    private readonly VitalsDbContext _db;
    private readonly IInpatientVerifier _verifier;
    private readonly ILogger<HourlyVitalsController> _logger;

    public HourlyVitalsController(
        VitalsDbContext db,
        IInpatientVerifier verifier,
        ILogger<HourlyVitalsController> logger)
    {
        _db = db;
        _verifier = verifier;
        _logger = logger;
    }

    private const string DayCompleteMessage =
        "This chart day is complete. Entries from a past day can no longer be created, edited or deleted.";

    private const string EntryLockedMessage =
        "This entry is locked (24 hours have passed since it was first saved). It can no longer be edited or deleted.";

    private ObjectResult Forbidden(string message) =>
        StatusCode(StatusCodes.Status403Forbidden, new { message });

    private static bool IsLocked(HourlyVitalEntry entry) =>
        ChartClock.Now - entry.ConfirmedAt >= EntryLockAfter;

    [HttpPost("confirm")]
    [ProducesResponseType(typeof(HourlyVitalEntry), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<HourlyVitalEntry>> ConfirmEntry(ConfirmHourlyEntryRequest request)
    {
        // Value ranges / text lengths are validated automatically ([ApiController] + the
        // attributes on ConfirmHourlyEntryRequest) and come back as a 400 before we get here.
        var problem = await _verifier.VerifyAsync(request.PatientIdentifier);
        if (problem is not null)
        {
            return StatusCode(problem.StatusCode, new { message = problem.Message });
        }

        var isNew = false;
        // Oracle 11g doesn't support FETCH FIRST (added in 12c), so we avoid
        // FirstOrDefaultAsync — it would add that clause. Our unique index
        // guarantees at most one match, so pulling the list and taking the
        // first item in memory is safe and avoids the unsupported SQL.
        HourlyVitalEntry? existing;

        if (request.EntryId.HasValue)
        {
            // Editing a specific entry: keep its original date and time.
            var byId = await _db.HourlyVitalEntries
                .Where(e => e.EntryId == request.EntryId.Value &&
                            e.PatientIdentifier == request.PatientIdentifier)
                .ToListAsync();
            existing = byId.FirstOrDefault();
            if (existing is null)
            {
                return NotFound(new { message = "Entry not found." });
            }

            // A completed (past) chart day is read-only.
            if (existing.EntryDate.Date < ChartClock.CurrentChartDate)
            {
                return Forbidden(DayCompleteMessage);
            }

            // Entries lock 24 hours after they were first saved.
            if (IsLocked(existing))
            {
                return Forbidden(EntryLockedMessage);
            }
        }
        else
        {
            // New entry: stamp it with the exact current time. The chart day runs
            // 07:00 -> 06:59, so anything before 07:00 belongs to the previous day.
            // "Hour" stores the exact time as HHmm (e.g. "1437"), which fits the
            // existing NVARCHAR2(4) column. Saving twice in the same minute updates
            // that minute's entry instead of violating the unique index.
            var now = ChartClock.Now;
            var chartDate = ChartClock.CurrentChartDate;
            var hour = now.ToString("HHmm");

            var matches = await _db.HourlyVitalEntries
                .Where(e =>
                    e.PatientIdentifier == request.PatientIdentifier &&
                    e.EntryDate == chartDate &&
                    e.Hour == hour)
                .ToListAsync();
            existing = matches.FirstOrDefault();

            if (existing is null)
            {
                existing = new HourlyVitalEntry
                {
                    PatientIdentifier = request.PatientIdentifier,
                    EntryDate = chartDate,
                    Hour = hour,
                    ConfirmedAt = now // India time, not the database server's clock
                };
                isNew = true;
            }
        }

        var entry = existing;

        entry.Temperature = request.Temperature;
        entry.RespiratoryRate = request.RespiratoryRate;
        entry.HeartRate = request.HeartRate;
        entry.PulseRate = request.PulseRate;
        entry.Iabp = request.Iabp;
        entry.SpO2 = request.SpO2;
        entry.NibpSystolic = request.NibpSystolic;
        entry.NibpDiastolic = request.NibpDiastolic;
        entry.Map = request.Map;
        entry.Cvp = request.Cvp;
        entry.BloodGlucose = request.BloodGlucose;
        entry.Insulin = request.Insulin;
        entry.AdrenalineStarted = request.AdrenalineStarted;
        entry.AdrenalineInfused = request.AdrenalineInfused;
        entry.NoradrenalineStarted = request.NoradrenalineStarted;
        entry.NoradrenalineInfused = request.NoradrenalineInfused;
        entry.DopamineStarted = request.DopamineStarted;
        entry.DopamineInfused = request.DopamineInfused;
        entry.DobutamineStarted = request.DobutamineStarted;
        entry.DobutamineInfused = request.DobutamineInfused;
        entry.ParenteralNutrition = request.ParenteralNutrition;
        entry.RtFeeds = request.RtFeeds;
        entry.Iv1 = request.Iv1;
        entry.Iv2 = request.Iv2;
        entry.Drains = request.Drains;
        entry.Stool = request.Stool;
        entry.Urine = request.Urine;
        entry.VentMode = request.VentMode;
        entry.Fio2 = request.Fio2;
        entry.RateSet = request.RateSet;
        entry.RateSpont = request.RateSpont;
        entry.TidalSet = request.TidalSet;
        entry.TidalSpont = request.TidalSpont;
        entry.MinVolSet = request.MinVolSet;
        entry.MinVolSpont = request.MinVolSpont;
        entry.Pc = request.Pc;
        entry.Peep = request.Peep;
        entry.Ps = request.Ps;
        entry.Pip = request.Pip;
        entry.VentSpo2 = request.VentSpo2;
        entry.Etco2 = request.Etco2;
        entry.Abg = request.Abg;
        entry.GcsEye = request.GcsEye;
        entry.GcsMotor = request.GcsMotor;
        entry.GcsVerbal = request.GcsVerbal;
        entry.MotorUpperR = request.MotorUpperR;
        entry.MotorUpperL = request.MotorUpperL;
        entry.MotorLowerR = request.MotorLowerR;
        entry.MotorLowerL = request.MotorLowerL;
        entry.PupilR = request.PupilR;
        entry.PupilL = request.PupilL;
        entry.ExtractionConfidence = request.ExtractionConfidence;

        if (isNew)
        {
            _db.HourlyVitalEntries.Add(entry);
        }

        await _db.SaveChangesAsync();
        _logger.LogInformation("Confirmed entry for Patient {PatientIdentifier}, {Date} {Hour}",
            entry.PatientIdentifier, entry.EntryDate, entry.Hour);

        return Ok(entry);
    }

    [HttpGet("patient/{patientIdentifier}/date/{date}")]
    [ProducesResponseType(typeof(List<HourlyVitalEntry>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<HourlyVitalEntry>>> GetEntriesForDate(string patientIdentifier, DateTime date)
    {
        var entries = await _db.HourlyVitalEntries
            .Where(e => e.PatientIdentifier == patientIdentifier && e.EntryDate == date.Date)
            .OrderBy(e => e.Hour)
            .ToListAsync();

        return Ok(entries);
    }

    [HttpDelete("{entryId:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteEntry(int entryId)
    {
        // Same reasoning as above — avoid FindAsync's single-row SQL pattern on 11g.
        var matches = await _db.HourlyVitalEntries.Where(e => e.EntryId == entryId).ToListAsync();
        var entry = matches.FirstOrDefault();
        if (entry is null)
        {
            return NotFound(new { message = "Entry not found." });
        }

        if (entry.EntryDate.Date < ChartClock.CurrentChartDate)
        {
            return Forbidden(DayCompleteMessage);
        }

        if (IsLocked(entry))
        {
            return Forbidden(EntryLockedMessage);
        }

        _db.HourlyVitalEntries.Remove(entry);
        await _db.SaveChangesAsync();
        _logger.LogInformation("Deleted hourly entry {EntryId}", entryId);
        return NoContent();
    }
}