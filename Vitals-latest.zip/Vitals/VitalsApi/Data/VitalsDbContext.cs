﻿using Microsoft.EntityFrameworkCore;
using VitalsApi.Models;

namespace VitalsApi.Data;

public class VitalsDbContext : DbContext
{
    public VitalsDbContext(
        DbContextOptions<VitalsDbContext> options)
        : base(options)
    {
    }

    public DbSet<HourlyVitalEntry> HourlyVitalEntries
        => Set<HourlyVitalEntry>();

    public DbSet<PatientLab> PatientLabs
        => Set<PatientLab>();

    public DbSet<PatientOrder> PatientOrders
        => Set<PatientOrder>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // -----------------------------------------------------
        // Hourly vitals
        // -----------------------------------------------------
        modelBuilder.Entity<HourlyVitalEntry>(entity =>
        {
            entity.ToTable("HOURLYVITALENTRIES");

            entity.HasKey(e => e.EntryId)
                .HasName("PK_HOURLYVITALENTRIES");

            entity.Property(e => e.EntryId)
                .ValueGeneratedOnAdd();

            entity.Property(e => e.Temperature)
                .HasPrecision(5, 1);

            entity.Property(e => e.EntryDate)
                .HasColumnType("TIMESTAMP(0)");

            entity.Property(e => e.ConfirmedAt)
                .HasColumnType("TIMESTAMP(0)")
                .HasDefaultValueSql("SYSTIMESTAMP")
                .ValueGeneratedOnAdd();

            entity.HasIndex(e => new
            {
                e.PatientIdentifier,
                e.EntryDate,
                e.Hour
            })
                .IsUnique()
                .HasDatabaseName("IX_HVE_PATIENT_DATE_HOUR");
        });

        // -----------------------------------------------------
        // Patient labs
        // -----------------------------------------------------
        modelBuilder.Entity<PatientLab>(entity =>
        {
            entity.ToTable("PATIENTLABS");

            entity.HasKey(e => e.LabId)
                .HasName("PK_PATIENTLABS");

            entity.Property(e => e.LabId)
                .ValueGeneratedOnAdd();

            entity.Property(e => e.LabDate)
                .HasColumnType("TIMESTAMP(0)");

            entity.Property(e => e.UpdatedAt)
                .HasColumnType("TIMESTAMP(0)");

            entity.HasIndex(e => new
            {
                e.PatientIdentifier,
                e.LabDate
            })
                .HasDatabaseName("IX_PL_PATIENT_DATE");
        });

        // -----------------------------------------------------
        // Patient medication orders
        // -----------------------------------------------------
        modelBuilder.Entity<PatientOrder>(entity =>
        {
            entity.ToTable("PATIENTORDERS");

            entity.HasKey(e => e.OrderId)
                .HasName("PK_PATIENTORDERS");

            entity.Property(e => e.OrderId)
                .ValueGeneratedOnAdd();

            entity.Property(e => e.UpdatedAt)
                .HasColumnType("TIMESTAMP(0)");

            entity.HasIndex(e => e.PatientIdentifier)
                .HasDatabaseName("IX_PO_PATIENT");
        });

        // -----------------------------------------------------
        // Match columns created WITHOUT quotes in Oracle.
        // -----------------------------------------------------
        var mappedTypes = new[]
        {
            typeof(HourlyVitalEntry),
            typeof(PatientLab),
            typeof(PatientOrder)
        };

        foreach (var clrType in mappedTypes)
        {
            var entityType = modelBuilder.Model.FindEntityType(clrType);

            if (entityType is null)
                continue;

            foreach (var property in entityType.GetProperties())
            {
                property.SetColumnName(
                    property.Name.ToUpperInvariant());
            }
        }
    }
}